"""
ts_agent.explainability.explainer
==================================
End-to-end explainability — Layers L1–L5 (Section 12).

L1  Graph path        — Neo4j traversal (handled by graph layer)
L2  ML explanation    — SHAP values in SegmentHypothesis
L3  Symbolic trace    — rule evaluation log in ExplainabilityBundle
L4  Rationale doc     — human-readable PDF (assembled by RationaleAssembler)
L5  Consumer explain  — PS25/22 §8.4 template-rendered plain English

INV-06: Consumer explanation MUST be generated from a PS25/22-approved
        Jinja2 template.  Free-text LLM output MUST NOT be served.
"""

from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass
from typing import Any

from jinja2 import Environment, StrictUndefined

from ts_agent.domain.models import (
    ExplainabilityBundle,
    GateDisposition,
    RuleEvaluation,
    RuleRejection,
    RuleType,
    SegmentHypothesis,
    TraitGraph,
)
from ts_agent.observability import signals as eamgp

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# FCA-approved template strings (INV-06)
# ──────────────────────────────────────────────────────────────────────────────

_SUGGESTION_TEMPLATE_SRC = """\
⚠ TARGETED SUPPORT — This is targeted support, not personalised financial advice.

Based on information about customers who share similar financial \
characteristics to yours, we thought you might find the following helpful:

  {{ suggestion_name }}

Customers in a similar situation often share these characteristics:
{%- for desc in characteristic_descriptions %}
  • {{ desc }}
{%- endfor %}

This recommendation has been designed for a group of customers who share \
similar financial characteristics. It has not been made based on a \
comprehensive review of your individual financial circumstances.
{%- if capital_at_risk %}

⚠ Capital at risk: The value of investments can fall as well as rise. \
You may get back less than you invest.
{%- endif %}
{%- if moneyhelper_signpost %}

Free impartial guidance: For free guidance on this topic, visit \
MoneyHelper at moneyhelper.org.uk
{%- endif %}
{%- if pension_wise_signpost %}
Pension guidance: For free impartial pensions guidance, visit \
Pension Wise at moneyhelper.org.uk/pensionwise
{%- endif %}
{%- if no_consolidation_statement %}

This suggestion does not involve combining or moving any pension pots.
{%- endif %}

For advice tailored to your individual circumstances, please contact: \
{{ advisor_url }}

Reference: {{ audit_id }} | FCA firm: {{ fca_firm_ref }}
"""

_NO_SUGGESTION_TEMPLATE_SRC = """\
Based on your current financial profile, we were unable to identify a \
targeted support suggestion appropriate for customers sharing your \
characteristics at this time.
{%- if top_reason %}

The primary reason is: {{ top_reason }}
{%- endif %}

For tailored guidance, please speak with one of our advisors: {{ advisor_url }}

Reference: {{ audit_id }}
"""

_jinja_env = Environment(undefined=StrictUndefined, autoescape=True)
_SUGGESTION_TEMPLATE  = _jinja_env.from_string(_SUGGESTION_TEMPLATE_SRC)
_NO_SUGGESTION_TEMPLATE = _jinja_env.from_string(_NO_SUGGESTION_TEMPLATE_SRC)

# Consumer-safe rejection reasons (INV-06 / PS25/22 DEL-002).
# Imported from config.segments — single source of truth for rule→reason mapping.
# Covers both legacy R-00x IDs and v2 compliance check IDs (PDC-*, DEL-*, etc.).
from ts_agent.config.settings import settings
from ts_agent.config.segments import CONSUMER_REASON_MAP  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────────
# Symbolic trace builder
# ──────────────────────────────────────────────────────────────────────────────

def build_symbolic_trace(evaluations: list[RuleEvaluation]) -> list[dict[str, Any]]:
    """
    Convert rule evaluation results to a structured trace (INV-10).

    The trace records every rule — PASS, FAIL, and GATE — so the FCA can
    reconstruct the full decision path.
    """
    return [
        {
            "rule_id":        ev.rule_id,
            "rule_type":      ev.rule_type.value,
            "input_value":    str(ev.input_value),
            "expected_value": str(ev.expected_value),
            "operator":       ev.operator,
            "outcome":        ev.outcome,
        }
        for ev in evaluations
    ]


# ──────────────────────────────────────────────────────────────────────────────
# Consumer explainer (L5)
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class SuggestionContext:
    """
    Data needed to render the L5 suggestion template.

    v2: Includes PS25/22 mandatory disclosure flags (DEL-004 through DEL-008).
    All boolean flags default to False; set to True based on suggestion domain
    and product type.
    """
    suggestion_name:             str
    characteristic_descriptions: list[str]
    advisor_url:                 str
    fca_firm_ref:                str
    # PS25/22 mandatory disclosure flags
    capital_at_risk:         bool = False   # DEL-005: investment products
    moneyhelper_signpost:    bool = True    # DEL-006: mandatory on ALL suggestions
    pension_wise_signpost:   bool = False   # DEL-006: mandatory for pension domains
    no_consolidation_statement: bool = False  # DEL-014: pension domain affirmative check


class ConsumerExplainer:
    """
    Generates L5 consumer-facing explanation text (INV-06).

    Template rendering is synchronous and deterministic.  Never calls an LLM.
    """

    def __init__(
        self,
        advisor_url: str = settings.advisor_url,
        fca_firm_ref: str = settings.fca_firm_ref,
    ) -> None:
        self._advisor_url  = advisor_url
        self._fca_firm_ref = fca_firm_ref

    def explain_suggestion(
        self,
        bundle: ExplainabilityBundle,
        suggestion_context: SuggestionContext,
    ) -> str:
        """
        Render the suggestion explanation template.
        Emits CONSUMER_EXPLAIN_SERVED.
        """
        text = _SUGGESTION_TEMPLATE.render(
            suggestion_name=suggestion_context.suggestion_name,
            characteristic_descriptions=suggestion_context.characteristic_descriptions,
            advisor_url=suggestion_context.advisor_url,
            fca_firm_ref=suggestion_context.fca_firm_ref,
            audit_id=bundle.audit_id,
            # PS25/22 mandatory disclosure flags (DEL-004 – DEL-008)
            capital_at_risk=suggestion_context.capital_at_risk,
            moneyhelper_signpost=suggestion_context.moneyhelper_signpost,
            pension_wise_signpost=suggestion_context.pension_wise_signpost,
            no_consolidation_statement=suggestion_context.no_consolidation_statement,
        )
        eamgp.emit(
            "CONSUMER_EXPLAIN_SERVED",
            eamgp.INFO,
            "Zone4",
            session_id=bundle.session_id,
            audit_id=bundle.audit_id,
            explanation_template="SUGGESTION_TEMPLATE",
        )
        return text

    def explain_no_suggestion(
        self,
        bundle: ExplainabilityBundle,
        rejections: list[RuleRejection],
    ) -> str:
        """
        Render the no-suggestion explanation template.
        Safe rejection reason is looked up from ``CONSUMER_REASON_MAP``.
        """
        top_reason: str | None = None
        if rejections:
            rule_id = rejections[0].rule_evaluation.rule_id
            top_reason = CONSUMER_REASON_MAP.get(rule_id)

        text = _NO_SUGGESTION_TEMPLATE.render(
            top_reason=top_reason,
            advisor_url=self._advisor_url,
            audit_id=bundle.audit_id,
        )
        eamgp.emit(
            "CONSUMER_EXPLAIN_SERVED",
            eamgp.INFO,
            "Zone4",
            session_id=bundle.session_id,
            audit_id=bundle.audit_id,
            explanation_template="NO_SUGGESTION_TEMPLATE",
        )
        return text

    @staticmethod
    def hash_communication_text(text: str) -> str:
        """SHA-256 of the consumer message — stored in audit, not the raw text."""
        return hashlib.sha256(text.encode()).hexdigest()


# ──────────────────────────────────────────────────────────────────────────────
# ExplainabilityBundle builder helpers
# ──────────────────────────────────────────────────────────────────────────────

def populate_zone1_fields(
    bundle: ExplainabilityBundle,
    graph: TraitGraph,
    latency_ms: int,
) -> ExplainabilityBundle:
    """Attach Zone 1 data to the bundle."""
    bundle.known_traits = [
        {
            "char_id":          n.char_id,
            "value_hash":       n.value_hash(),
            "populated_source": n.populated_source,
        }
        for n in graph.known_nodes()
    ]
    bundle.missing_traits  = [n.char_id for n in graph.missing_nodes()]
    bundle.excluded_traits = [
        {
            "char_id":          n.char_id,
            "exclusion_reason": n.populated_source,
            "fca_ref":          n.fca_ref,
        }
        for n in graph.excluded_nodes()
    ]
    bundle.zone1_latency_ms = latency_ms
    return bundle


def populate_zone15_fields(
    bundle: ExplainabilityBundle,
    hypothesis: SegmentHypothesis,
) -> ExplainabilityBundle:
    """Attach Zone 1.5 (ML predictor) data to the bundle."""
    bundle.final_hypothesis = hypothesis.to_neo4j_params()
    bundle.shap_values = [
        {"feature": f.feature, "shap_value": f.shap_value, "rank": f.rank}
        for f in hypothesis.shap_top_features
    ]
    bundle.model_version   = hypothesis.model_version
    bundle.model_algorithm = hypothesis.model_algorithm.value
    return bundle


def populate_zone3_fields(
    bundle: ExplainabilityBundle,
    evaluations: list[RuleEvaluation],
    gate_disposition: GateDisposition,
    candidates_evaluated: list[dict[str, Any]],
    validated_candidates: list[dict[str, Any]],
    rejections: list[RuleRejection],
) -> ExplainabilityBundle:
    """Attach Zone 3 validation data to the bundle (INV-10)."""
    bundle.symbolic_trace       = build_symbolic_trace(evaluations)  # INV-10
    bundle.gate_disposition     = gate_disposition
    bundle.candidates_evaluated = candidates_evaluated
    bundle.validated_candidates = validated_candidates
    bundle.rejected_candidates  = [
        {
            "suggestion_id":  r.suggestion_id,
            "rule_failed":    r.rule_evaluation.rule_id,
            "consumer_reason": r.consumer_reason,
        }
        for r in rejections
    ]
    return bundle
