"""
ts_agent.zones.zone3.delivery_agent
=====================================
Zone 3 — Delivery Agent (ADK LlmAgent)

Responsibilities
----------------
- Receive the validated SuggestionResult from SuggestionEngine.
- Construct the consumer-facing message from the PS25/22-approved template.
- Enforce the audit-before-delivery gate (INV-05).
- Emit the final consumer message.

In production the audit write is to Cloud Spanner; in tests/local dev
a no-op writer is injected.  The agent itself never writes — it delegates
to the delivery coordinator which calls it after the audit gate.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

# google.adk imports removed — DeliveryCoordinator is a plain Python class
# and does not require ADK at runtime. The LlmAgent reference in the docstring
# refers to zone2/agent.py, not this file.

from ts_agent.domain.models import ExplainabilityBundle, GateDisposition
from ts_agent.explainability.explainer import ConsumerExplainer, SuggestionContext
from ts_agent.observability import signals as eamgp
from ts_agent.zones.zone3.suggestion_engine import SuggestionResult

logger = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────────────────────
# Delivery result
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class DeliveryResult:
    """Outcome of Zone 4 output construction."""
    session_id:         str
    audit_id:           str
    gate_disposition:   GateDisposition
    consumer_message:   str | None     # None when SUPPRESS
    communication_hash: str | None
    audit_confirmed:    bool           # False until Spanner write confirmed
    error:              str | None = None


# ──────────────────────────────────────────────────────────────────────────────
# Delivery coordinator (called directly from orchestrator, not via ADK loop)
# ──────────────────────────────────────────────────────────────────────────────

class DeliveryCoordinator:
    """
    Pure-Python coordinator that assembles the consumer message and enforces
    the audit-before-delivery gate (INV-05).

    This is NOT an ADK agent — it is a synchronous service called by the
    pipeline after Zone 3 has produced a ``SuggestionResult``.
    """

    def __init__(
        self,
        explainer: ConsumerExplainer | None = None,
        advisor_url: str = "https://www.lloydsbank.com/financial-advice",
        fca_firm_ref: str = "FRN-119278",
    ) -> None:
        self._explainer   = explainer or ConsumerExplainer(
            advisor_url=advisor_url,
            fca_firm_ref=fca_firm_ref,
        )

    def deliver(
        self,
        result: SuggestionResult,
        bundle: ExplainabilityBundle,
    ) -> DeliveryResult:
        """
        Build consumer message and return a DeliveryResult.

        INV-05: audit_confirmed is always False until the caller confirms
        the Spanner write.  The caller must not surface the message to the
        consumer until audit_confirmed = True.
        """
        session_id = bundle.session_id

        eamgp.emit(
            "OUTPUT_CONSTRUCTED", eamgp.INFO, "Zone4",
            session_id=session_id,
            gate_disposition=result.gate_disposition.value,
            audit_id=bundle.audit_id,
        )

        if result.gate_disposition == GateDisposition.SUPPRESS or not result.top_suggestion:
            msg = self._explainer.explain_no_suggestion(
                bundle, result.all_rejections()
            )
            comm_hash = ConsumerExplainer.hash_communication_text(msg)
            bundle.communication_text_hash = comm_hash
            bundle.consumer_explanation     = msg
            return DeliveryResult(
                session_id=session_id,
                audit_id=bundle.audit_id,
                gate_disposition=result.gate_disposition,
                consumer_message=None,     # INV-05: suppressed until audit
                communication_hash=comm_hash,
                audit_confirmed=False,
            )

        sugg = result.top_suggestion
        from ts_agent.config.segments import SEGMENTS
        seg_def = SEGMENTS.get(result.segment_id)

        ctx = SuggestionContext(
            suggestion_name=sugg.product_name,
            characteristic_descriptions=list(
                seg_def.characteristic_descriptions if seg_def else []
            ),
            advisor_url=self._explainer._advisor_url,
            fca_firm_ref=self._explainer._fca_firm_ref,
        )
        msg       = self._explainer.explain_suggestion(bundle, ctx)
        comm_hash = ConsumerExplainer.hash_communication_text(msg)
        bundle.communication_text_hash = comm_hash
        bundle.consumer_explanation     = msg

        eamgp.emit(
            "AUDIT_WRITE_START", eamgp.INFO, "Zone4",
            session_id=session_id,
            audit_id=bundle.audit_id,
        )

        return DeliveryResult(
            session_id=session_id,
            audit_id=bundle.audit_id,
            gate_disposition=result.gate_disposition,
            consumer_message=msg,           # caller holds until audit confirmed
            communication_hash=comm_hash,
            audit_confirmed=False,          # INV-05
        )

    def confirm_audit(self, delivery_result: DeliveryResult) -> DeliveryResult:
        """
        Called after Cloud Spanner audit write is confirmed.
        Sets audit_confirmed = True, releasing the delivery gate.
        """
        from dataclasses import replace
        eamgp.emit(
            "AUDIT_WRITE_CONFIRMED", eamgp.INFO, "Zone4",
            session_id=delivery_result.session_id,
            audit_id=delivery_result.audit_id,
        )
        return replace(delivery_result, audit_confirmed=True)
