"""
ts_agent.zones.zone2.agent
===========================
Zone 2 — Gap-Fill Conversational Agent (ADK LlmAgent)

Architecture
------------
The Gap-Fill Agent is an ``LlmAgent`` that drives a structured conversation
to collect the MISSING traits from the consumer.  It uses four ``FunctionTool``
objects defined in ``zone2.tools`` to:

1. ``get_next_question``     — decide which trait to ask about next
2. ``record_consumer_answer`` — write the consumer's answer into the TraitGraph
3. ``check_graph_completeness`` — decide when to stop asking
4. ``match_segment``         — run deterministic segment matching once ready

The agent is stateless between turns (state lives in ADK ``session.state``).
The system instruction embeds the FCA PS25/22 conversational guardrails.

Testing without a live LLM
---------------------------
All tools are individually unit-testable by constructing a ``ToolContext``
with a mock ``InvocationContext``.  The agent-level integration tests use
``TestRunner`` (see ``tests/unit/zones/zone2/test_agent.py``) which drives
the agent loop with a mock LLM.
"""
from __future__ import annotations

from google.adk.agents import LlmAgent

from ts_agent.zones.zone2.tools import (
    CHECK_COMPLETENESS_TOOL,
    GET_NEXT_QUESTION_TOOL,
    MATCH_SEGMENT_TOOL,
    RECORD_ANSWER_TOOL,
)

# ── System instruction ────────────────────────────────────────────────────────

_SYSTEM_INSTRUCTION = """\
You are the LBG Targeted Support conversational assistant.  Your role is to
collect missing financial profile information from the consumer in a natural,
empathetic conversation so that we can identify the most relevant targeted
support suggestion for them.

STRICT RULES — YOU MUST FOLLOW THESE WITHOUT EXCEPTION:
1. Ask only ONE question per turn.  Never ask two questions in the same message.
2. You MUST use the available tools to drive the conversation — never guess
   or fabricate a consumer's profile values.
3. When you have an answer from the consumer, ALWAYS call ``record_consumer_answer``
   before proceeding.
4. After recording an answer, call ``check_graph_completeness``.  When
   ``ready_for_match`` is True, call ``match_segment`` to determine the
   consumer's segment.
5. NEVER mention products, suggestions, or recommendations during gap-fill.
   Only gather information.
6. NEVER ask about financial values that have already been answered.
   Call ``get_next_question`` to find out what to ask next.
7. If the consumer says they do not know an answer or declines, acknowledge
   politely and move on — call ``record_consumer_answer`` with value "unknown".
8. Keep questions simple, jargon-free, and appropriate for all literacy levels.
9. Always remind the consumer their information is used only to find suitable
   support and is handled under LBG's privacy policy.

CONVERSATION FLOW:
- Start: call ``get_next_question`` to get the first trait to ask.
- Ask the question in natural language.
- When the consumer answers: call ``record_consumer_answer``.
- Call ``check_graph_completeness``.
- If ``ready_for_match`` is False: call ``get_next_question`` again for the next trait.
- If ``ready_for_match`` is True: call ``match_segment`` and report the conversation
  is complete, saying "Thank you — I have everything I need."
- If ``done`` is True with no ``char_id``: call ``match_segment`` directly.
"""

# ── Agent factory ─────────────────────────────────────────────────────────────

def create_gap_fill_agent(
    model: str | None = None,
) -> LlmAgent:
    """Create the Zone 2 gap-fill agent.  ``model`` defaults to ``settings.gemini_model``."""
    model = model or settings.gemini_model
    """
    Create and return the Zone 2 Gap-Fill LlmAgent.

    Parameters
    ----------
    model :
        Vertex AI / Gemini model identifier.  Defaults to
        ``"gemini-2.0-flash"`` which is fast enough for real-time
        conversational turns.

    Returns
    -------
    LlmAgent
        Configured with the four Zone 2 tools and the FCA system instruction.
    """
    return LlmAgent(
        name="gap_fill_agent",
        model=model,
        instruction=_SYSTEM_INSTRUCTION,
        tools=[
            GET_NEXT_QUESTION_TOOL,
            RECORD_ANSWER_TOOL,
            CHECK_COMPLETENESS_TOOL,
            MATCH_SEGMENT_TOOL,
        ],
    )


# ── Module-level singleton (convenience for test imports) ─────────────────────
GAP_FILL_AGENT = create_gap_fill_agent()
