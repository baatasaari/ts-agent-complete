"""
ts_agent.zones.zone1_graph_builder
===================================
Zone 1 — TraitGraphBuilder

Deterministic construction of the TraitGraph from bank data sources.

Design contract
---------------
- No LLM calls.
- The only I/O is the async Neo4j write (injected dependency).
- Must complete < 300 ms p99 including the Neo4j write (Option A).
- DEPENDS_ON and CONFLICTS_WITH edges are built purely from YAML config
  (fill_priority ordering and conflict_pairs), not from ML or LLM output.
"""

from __future__ import annotations

import time
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Protocol

from ts_agent.domain.models import (
    EdgeType,
    GraphEdge,
    NodeBranch,
    NodeState,
    TraitGraph,
    TraitNode,
)
from ts_agent.observability import signals as eamgp


# ──────────────────────────────────────────────────────────────────────────────
# Configuration types (loaded from YAML in production)
# ──────────────────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class TraitConfig:
    """Static configuration for one trait node (from characteristics.yaml)."""
    char_id:           str
    branch:            NodeBranch
    label:             str
    op:                str
    target_value:      Any
    data_sources:      tuple[str, ...]
    aging:             str
    fill_priority:     int
    email_test_node:   bool          = False
    fill_question_key: str | None    = None
    fca_ref:           str | None    = None


@dataclass(frozen=True)
class ConflictPair:
    """A pair of trait char_ids that are mutually exclusive for segment routing."""
    node_a:            str
    node_b:            str
    affected_segments: tuple[str, ...]


@dataclass
class SituationConfig:
    """Loaded from situation_config.yaml — maps intents to situations."""
    situation_id:   str
    intent_ids:     list[str]
    trait_configs:  list[TraitConfig]
    conflict_pairs: list[ConflictPair] = field(default_factory=list)


# ──────────────────────────────────────────────────────────────────────────────
# Bank data / user profile (injected from upstream data sources)
# ──────────────────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class ClassifiedIntent:
    intent_id:   str
    confidence:  float
    channel:     str = "mobile"


@dataclass
class UserProfile:
    """
    Aggregated bank data available at session start.
    Populated from OCIS, CBS/Vault, FICO, AOV, LBG CC Systems.
    """
    party_ref: str
    # Populated fields map char_id → raw value from source system.
    # Missing keys mean the source system has no data for this trait.
    bank_data: dict[str, Any] = field(default_factory=dict)


# ──────────────────────────────────────────────────────────────────────────────
# Graph writer protocol (for dependency injection / testability)
# ──────────────────────────────────────────────────────────────────────────────

class GraphWriter(Protocol):
    """Interface that Zone 1 uses to persist the TraitGraph."""

    async def write_hard(self, graph: TraitGraph) -> None:
        """Persist the full session graph. Raises on failure (HARD gate)."""
        ...


# ──────────────────────────────────────────────────────────────────────────────
# TraitGraphBuilder
# ──────────────────────────────────────────────────────────────────────────────

class TraitGraphBuilder:
    """
    Zone 1 — builds a TraitGraph from bank data for a given intent + profile.

    Callers inject the config and writer; this class owns no I/O state itself,
    making it trivially testable with mock writers.
    """

    def __init__(
        self,
        config: SituationConfig,
        writer: GraphWriter,
    ) -> None:
        self._config = config
        self._writer = writer

    # ── Public entry point ────────────────────────────────────────────────────

    async def build(
        self,
        intent: ClassifiedIntent,
        user_profile: UserProfile,
    ) -> TraitGraph:
        """
        Construct and persist the TraitGraph for one TS session.

        Steps
        -----
        1. Initialise graph with one TraitNode per config entry.
        2. Apply mode exclusions (email/non-email).
        3. Apply intent exclusions (traits not relevant for this intent).
        4. Populate known values from bank data.
        5. Build DEPENDS_ON edges (fill_priority topology).
        6. Build CONFLICTS_WITH edges (mutual-exclusion pairs).
        7. Async Neo4j write (HARD gate).
        8. Emit GRAPH_BUILD_COMPLETE.
        """
        start = time.perf_counter()

        eamgp.emit(
            "GRAPH_BUILD_START",
            eamgp.INFO,
            "Zone1",
            session_id="",   # not yet known — set below
            intent_id=intent.intent_id,
            situation_id=self._config.situation_id,
        )

        graph = self._init_graph(intent, user_profile)
        graph = self._apply_mode_exclusions(graph, intent)
        graph = self._apply_intent_exclusions(graph, intent)
        graph = self._populate_bank_data(graph, user_profile)
        graph = self._build_dependency_edges(graph)
        graph = self._build_conflict_edges(graph)

        # HARD gate: Neo4j write must succeed before returning
        await self._writer.write_hard(graph)

        latency_ms = int((time.perf_counter() - start) * 1_000)
        stats = graph.stats()

        eamgp.emit(
            "GRAPH_BUILD_COMPLETE",
            eamgp.INFO,
            "Zone1",
            session_id=graph.session_id,
            node_count=stats["total"],
            edge_count=stats["edges"],
            known_count=stats["known"],
            missing_count=stats["missing"],
            excluded_count=stats["excluded"],
            latency_ms=latency_ms,
        )
        return graph

    # ── Internal stages ───────────────────────────────────────────────────────

    def _init_graph(
        self,
        intent: ClassifiedIntent,
        user_profile: UserProfile,
    ) -> TraitGraph:
        graph = TraitGraph(
            party_ref=user_profile.party_ref,
            intent_id=intent.intent_id,
            situation_id=self._config.situation_id,
        )
        for cfg in self._config.trait_configs:
            node = TraitNode(
                node_id=f"{graph.session_id}::{cfg.char_id}",
                char_id=cfg.char_id,
                branch=cfg.branch,
                label=cfg.label,
                op=cfg.op,
                target_value=cfg.target_value,
                data_sources=cfg.data_sources,
                aging=cfg.aging,
                fill_priority=cfg.fill_priority,
                fill_question_key=cfg.fill_question_key,
                fca_ref=cfg.fca_ref,
                email_test_node=cfg.email_test_node,
            )
            graph.add_node(node)
        return graph

    def _apply_mode_exclusions(
        self,
        graph: TraitGraph,
        intent: ClassifiedIntent,
    ) -> TraitGraph:
        """Exclude email-test nodes when session is not an email channel."""
        if intent.channel == "email":
            return graph
        for node in list(graph.nodes.values()):
            if node.email_test_node:
                updated = node.with_state(
                    NodeState.EXCLUDED,
                    populated_source="MODE_EXCLUSION",
                )
                graph.update_node(updated)
                eamgp.emit(
                    "GRAPH_NODE_EXCLUDED",
                    eamgp.INFO,
                    "Zone1",
                    session_id=graph.session_id,
                    node_id=node.node_id,
                    char_id=node.char_id,
                    exclusion_reason="EMAIL_ONLY_NODE_NON_EMAIL_CHANNEL",
                    fca_ref=node.fca_ref,
                )
        return graph

    def _apply_intent_exclusions(
        self,
        graph: TraitGraph,
        intent: ClassifiedIntent,
    ) -> TraitGraph:
        """
        Nodes can be tagged with ``fca_ref`` patterns that indicate they are
        only relevant for specific intent families.  This is a placeholder hook
        — real logic lives in the YAML intent_exclusion_map.
        """
        # In v1.3 no intent-level exclusions are wired; the hook is present for
        # future extension without touching callers.
        return graph

    def _populate_bank_data(
        self,
        graph: TraitGraph,
        user_profile: UserProfile,
    ) -> TraitGraph:
        """Mark traits KNOWN where bank data is available."""
        for node in list(graph.nodes.values()):
            if node.state == NodeState.EXCLUDED:
                continue
            if node.char_id in user_profile.bank_data:
                raw_value = user_profile.bank_data[node.char_id]
                source = next(iter(node.data_sources), "UNKNOWN_SOURCE")
                updated = node.with_state(
                    NodeState.KNOWN,
                    value=raw_value,
                    populated_source=source,
                )
                graph.update_node(updated)
                eamgp.emit(
                    "GRAPH_NODE_POPULATED",
                    eamgp.INFO,
                    "Zone1",
                    session_id=graph.session_id,
                    node_id=node.node_id,
                    char_id=node.char_id,
                    source_system=source,
                    state_before=NodeState.MISSING.value,
                    state_after=NodeState.KNOWN.value,
                    value_hash=updated.value_hash(),
                )
        return graph

    def _build_dependency_edges(self, graph: TraitGraph) -> TraitGraph:
        """
        Build DEPENDS_ON edges from fill_priority ordering.

        Every MISSING node at priority N depends on all MISSING nodes at
        priority N-1.  This encodes fill order as graph topology so
        Pattern 4 BFS (Section 3.6) can resolve it dynamically.
        """
        by_priority: dict[int, list[TraitNode]] = defaultdict(list)
        for node in graph.nodes.values():
            if node.state == NodeState.MISSING:
                by_priority[node.fill_priority].append(node)

        sorted_prios = sorted(by_priority.keys())
        for idx, prio in enumerate(sorted_prios[1:], start=1):
            prev_prio = sorted_prios[idx - 1]
            for hi_node in by_priority[prio]:
                for lo_node in by_priority[prev_prio]:
                    graph.add_edge(GraphEdge(
                        from_id=hi_node.node_id,
                        to_id=lo_node.node_id,
                        edge_type=EdgeType.DEPENDS_ON,
                        properties={"reason": "fill_priority_ordering"},
                    ))

        dep_edges = [e for e in graph.edges if e.edge_type == EdgeType.DEPENDS_ON]
        eamgp.emit(
            "GRAPH_DEPENDENCY_BUILT",
            eamgp.INFO,
            "Zone1",
            session_id=graph.session_id,
            edge_count=len(dep_edges),
        )
        return graph

    def _build_conflict_edges(self, graph: TraitGraph) -> TraitGraph:
        """
        Build CONFLICTS_WITH edges between mutually-exclusive segment nodes.
        Loaded from ``SituationConfig.conflict_pairs``.
        """
        built = 0
        for pair in self._config.conflict_pairs:
            node_a = graph.node_by_char_id(pair.node_a)
            node_b = graph.node_by_char_id(pair.node_b)
            if node_a and node_b:
                graph.add_edge(GraphEdge(
                    from_id=node_a.node_id,
                    to_id=node_b.node_id,
                    edge_type=EdgeType.CONFLICTS_WITH,
                    properties={
                        "reason":            "mutual_exclusion",
                        "affected_segments": list(pair.affected_segments),
                    },
                ))
                built += 1

        eamgp.emit(
            "GRAPH_CONFLICT_BUILT",
            eamgp.INFO,
            "Zone1",
            session_id=graph.session_id,
            conflict_pair_count=built,
        )
        return graph
